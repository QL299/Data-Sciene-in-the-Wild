Q2

For the code structure, see the annotations in the Q2.ipy and run it through jupyter notebook.